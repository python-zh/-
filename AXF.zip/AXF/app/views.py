from django.shortcuts import render

# Create your views here.
import hashlib
import json
import os
import uuid

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect, reverse

from AXF import config
from app import error_code
from app.utils import check_login, check_method
from django.views.decorators.csrf import csrf_exempt
# from pay.myalipay import alipay

from app.models import *
import re


# Create your views here.


# 首页
def home(request):
    # 轮播图
    wheels = MainWheel.objects.all()

    # 导航
    navs = MainNav.objects.all()

    # 必买
    mustbuys = MainMustbuy.objects.all()

    # 商店
    shops = MainShop.objects.all()
    shop0 = shops[0]
    shop1_2 = shops[1:3]
    shop3_6 = shops[3:7]
    shop7_10 = shops[7:11]

    # 主体数据
    mainshows = MainShow.objects.all()

    data = {
        'wheels': wheels,
        'navs': navs,
        'mustbuys': mustbuys,
        'shop0': shop0,
        'shop1_2': shop1_2,
        'shop3_6': shop3_6,
        'shop7_10': shop7_10,
        'mainshows': mainshows,

    }
    return render(request, 'home/home.html', data)


# 闪购
# def market(request):
def market(request, typeid, childtype_id, sorttype_id):
    foodtypes = FoodType.objects.all()
    goods = Good.objects.all()

    goods = goods.filter(categoryid=typeid)

    # 取到更当次点击主分类，相关的子分类
    foodtype_queryset = FoodType.objects.filter(typeid=typeid)
    childtypenames = foodtype_queryset.first().childtypenames
    # 打印一下内容
    print(childtypenames)  # 全部分类:0#进口水果:103534#国产水果:103533

    # 根据#号切割
    childtype_list = childtypenames.split('#')
    print(childtype_list)  # ['全部分类:0', '进口水果:103534', '国产水果:103533']

    childtype_list = [childtype.split(':') for childtype in childtype_list]
    # [['全部分类', '0'], ['进口水果', '103534'], ['国产水果', '103533']]

    # 如果没有点击子分类 childtype_id == 0
    # 如果点击了子分类
    if childtype_id != '0':
        # 根据子分类再筛选
        goods = goods.filter(childcid=childtype_id)

    print(childtype_list)

    # 对排序筛选
    if sorttype_id == '0':  # 综合排序呢
        pass
    elif sorttype_id == '1':  # 销量排序呢
        goods = goods.order_by('productnum')
    elif sorttype_id == '2':  # 价格降序
        goods = goods.order_by('-price')
    elif sorttype_id == '3':  # 价格升序
        goods = goods.order_by('price')

    data = {
        'foodtypes': foodtypes,
        'goods': goods,
        'typeid': typeid,
        'childtype_list': childtype_list,
    }

    return render(request, 'market/market.html', data)


# 购物车
def cart(request):
    userid = request.session.get('userid')
    # 如果没有登录
    if not userid:
        # 跳转到登录页
        return redirect(reverse('axf:login'))
    # 筛选当前用户的购物车商品
    carts = Cart.objects.filter(user_id=userid)

    return render(request, 'cart/cart.html', {'carts': carts})


# 我的
def mine(request):
    username = ''
    icon = ''

    # 取到登录或注册时保存在session中的userid
    userid = request.session.get('userid')

    # 根据id找到用户
    users = User.objects.filter(id=userid)

    if users:
        username = users.first().username
        icon = users.first().icon

    data = {
        'username': username,
        'icon': icon,
    }
    return render(request, 'mine/mine.html', data)


# 注册
def register(request):
    return render(request, 'user/register.html')


# md5 hash
def my_md5(str):
    m = hashlib.md5()
    m.update(str.encode('utf-8'))

    return m.hexdigest()


# 注册操作
def register_handler(request):
    if request.method != 'POST':
        return HttpResponse('请求方式有误')

    username = request.POST.get('username')
    password = request.POST.get('password')
    re_password = request.POST.get('re_password')
    email = request.POST.get('email')

    icon = request.FILES.get('icon')

    # 如果其中有一项是空
    if not username or not password or not re_password or not email:
        return HttpResponse('您填写的信息不全')

    if password != re_password:
        return HttpResponse('两次密码不一致')
    # 如果用户名不是 6-18位的数字字母下划线,不能以数字开头
    if not re.match('^[a-zA-Z_]\w{5,17}$', username):
        return HttpResponse('用户名格式不正确')

    if not re.match('^.{8,}$', password):
        return HttpResponse('密码格式不正确')

    """
    admin@qq.com
    admin@bingjing.edu.cn.cn.uk

    \w{1,16}@\w+\.\w+


    """
    if not re.match('^\w{1,16}@\w+(\.\w+)+$', email):
        return HttpResponse('邮箱格式不正确')

    user = User()
    user.username = username
    user.password = my_md5(password)
    user.email = email

    user.save()

    request.session['userid'] = user.id

    # 如果有头像
    if icon:

        # 随机文件名 + 后缀
        filename = str(uuid.uuid4()) + os.path.splitext(icon.name)[1]

        # 保存的文件路径 MEDIA_ROOT + filename
        from AXF.settings import MEDIA_ROOT
        icon_save_path = os.path.join(MEDIA_ROOT, filename)

        # 取出头像的二进制保存
        with open(icon_save_path, 'ab') as fp:
            for part in icon.chunks():
                fp.write(part)

        # 把头像的路径保存到数据库中
        icon_db_save_path = '/uploads/' + filename

        user.icon = icon_db_save_path

        user.save()

    return redirect(reverse('axf:mine'))


def virify_user(request):
    username = request.GET.get('username')

    # 如果数据库中有这个用户
    if User.objects.filter(username=username).exists():
        return JsonResponse({'status': 1, 'msg': 'user exists'})

    return JsonResponse({'status': 0, 'msg': 'ok'})


# 登录
def login(request):
    return render(request, 'user/login.html')


# 登录操作
def login_handler(request):
    if request.method != 'POST':
        return HttpResponse('请求方式不对')

    username = request.POST.get('username')
    password = request.POST.get('password')

    # 用提交的用户名和密码去数据库中查询
    users = User.objects.filter(username=username, password=my_md5(password))
    # users = User.objects.filter(username=username, password=password)

    # 如果存在，说明用户名和密码的组合正确
    if users.exists():

        # 跳转我的页面，展示用户名和头像
        response = redirect(reverse('axf:mine'))

        request.session['userid'] = users.first().id

    # 用户名和密码 错误
    else:
        response = HttpResponse('用户名或密码错误')

    return response


# 注销
def logout(request):
    # del request.session['userid']

    # 把session中的userid删除
    request.session.pop('userid')

    # 把浏览器中的cookie删除
    request.session.flush()

    return redirect(reverse('axf:mine'))


# 添加到购物车
@check_method('GET')
@check_login
def add_to_cart(request):
    data = {
        'status': 1,
        'msg': 'add to cart success'
    }

    # 取到商品id
    goodsid = request.GET.get('goodsid')
    # 商品数量
    num = request.GET.get('num')

    # 判断数据库中有没有这条数据库中的记录
    carts = Cart.objects.filter(user_id=request.user.id, goods_id=goodsid)

    # 如有这条记录
    if carts.exists():
        cart = carts.first()
        cart.num += int(num)
        cart.save()

    # 如果没有这条记录
    else:

        cart = Cart()
        cart.goods_id = goodsid
        cart.num = num
        cart.user_id = request.user.id
        # cart.is_select=True
        cart.save()

    # 返回数据库中的数据
    data['num'] = cart.num

    return JsonResponse(data)


# 购物车商品数量增加
@check_method('POST')
@check_login
def cart_num_add(request):
    data = {
        'status': 1,
        'msg': 'num  add  success'
    }

    # 取到Ajax提交的cart.id
    cartid = request.POST.get("cartid")
    # 去数据库中查找有没有这条记录
    carts = Cart.objects.filter(user_id=request.user.id, id=cartid)
    # 如果没有
    if not carts.exists():
        data['status'] = error_code.NO_THIS_CART
        data['msg'] = 'no this cart'

    else:
        cart = carts.first()
        cart.num += 1
        cart.save()
        # 把数据库中的数量返回给前端
        data['num'] = cart.num

    return JsonResponse(data)


# 购物车商品数量减少
@check_method('POST')
@check_login
def cart_num_reduce(request):
    data = {
        'status': 1,
        'msg': 'num  reduce  success'
    }

    # 取到Ajax提交的cart.id
    cartid = request.POST.get("cartid")
    # 去数据库中查找有没有这条记录
    carts = Cart.objects.filter(user_id=request.user.id, id=cartid)
    # 如果没有
    if not carts.exists():
        data['status'] = error_code.NO_THIS_CART
        data['msg'] = 'no this cart'

    else:
        cart = carts.first()
        # 保证数量大于１
        if cart.num > 1:
            cart.num -= 1
            cart.save()
        # 把数据库中的数量返回给前端
        data['num'] = cart.num

    return JsonResponse(data)


# 删除购物车中商品
@check_method('POST')
@check_login
def cart_delete(request):
    data = {
        'status': 1,
        'msg': 'num  reduce  success'
    }

    # 取到Ajax提交的cart.id
    cartid = request.POST.get("cartid")
    # 去数据库中查找有没有这条记录
    carts = Cart.objects.filter(user_id=request.user.id, id=cartid)
    # 如果没有
    if not carts.exists():
        data['status'] = error_code.NO_THIS_CART
        data['msg'] = 'no this cart'

    else:
        # 删除购物车记录
        carts.delete()

    return JsonResponse(data)


# 勾选商品
@check_method('POST')
@check_login
def cart_select(request):
    data = {
        'status': 1,
        'msg': 'num reduce success'
    }

    # 取到ajax提交的cart.id
    cartid = request.POST.get('cartid')

    # 取数据中查找有没有这条记录
    carts = Cart.objects.filter(user_id=request.user.id, id=cartid)
    # 如果没有
    if not carts.exists():
        data['status'] = error_code.NO_THIS_CART
        data['msg'] = 'no this cart'

    else:
        # 取到勾选状态
        select = request.POST.get('select')

        cart = carts.first()
        cart.is_select = int(select)

        cart.save()

    return JsonResponse(data)


# 全选或全全不选
@check_method('POST')
@check_login
def all_select_or_none(request):
    data = {
        'status': 1,
        'msg': 'select success'
    }

    # 获得选择的状态
    all_select = request.POST.get('all_select')

    # 根据用户id，和选择状态来筛选购物车，如果前端上传的all_select就1，表示要给所有商品打钩，
    # 筛选所有没有打钩的购物车记录
    carts = Cart.objects.filter(user_id=request.user.id, is_select=not int(all_select))

    # 更新打钩的状态
    carts.update(is_select=int(all_select))

    return JsonResponse(data)


@csrf_exempt
def pay_result(request):
    data = request.GET.dict()

    # sign 不能参与签名验证
    signature = data.pop("sign")

    print(json.dumps(data))
    print(signature)

    # verify
    # success = alipay.verify(data, signature)
    # if success:
    #
    #     Order.objects.filter(order_id=data.get('out_trade_no')).update(status=1)
    #     # return HttpResponse('支付成功')
    #     return redirect(reverse('axf:mine'))
    #
    # else:
    #     return HttpResponse('支付有问题')


@check_login
def add_order(request):
    data = {
        'status': 1,
        'msg': 'add order success'
    }

    order = Order()
    order.order_id = my_md5(str(uuid.uuid4()))
    order.user_id = request.user.id

    order.save()

    # 查询当前用户的购物车
    carts = Cart.objects.filter(user_id=request.user.id)

    if not carts.exists():
        data['status'] = error_code.NO_THIS_CART
        data['msg'] = 'no this cart'

    else:

        total_price = 0
        # 把购车中的商品加入到商品订单表中
        for cart in carts:
            if cart.is_select:
                ordergoods = OrderGoods()
                ordergoods.goods_id = cart.goods_id
                ordergoods.order_id = order.id
                ordergoods.price = cart.goods.price
                ordergoods.num = cart.num

                ordergoods.save()

                # 计算总价
                total_price += ordergoods.price * ordergoods.num

        # 删除购物车中的商品
        carts.delete()

        order.price = total_price

        order.save()

    # 支付连接发给前端
    data['re_url'] = make_alipay_bill(order)

    return JsonResponse(data)


# 生成支付宝订单
# def make_alipay_bill(order):
#     # 手机网站支付 alipay.trade.wap.pay
#     order_string = alipay.api_alipay_trade_wap_pay(
#         out_trade_no=order.order_id,
#         total_amount=order.price,
#         subject='一些水果',
#         return_url="http://10.3.134.112:8000/axf/pay_result/",
#         notify_url="https://example.com/notify"  # 可选, 不填则使用默认notify url
#     )
#
#     alipay_url = 'https://openapi.alipaydev.com/gateway.do?'
#
#     re_url = alipay_url + order_string
#
#     return re_url


@check_login
def order_unpay(request):
    orders = Order.objects.filter(user_id=request.user.id, status=config.BILL_UNPAY)

    return render(request, 'order/orderunpay.html', {'orders': orders})


@check_method('POST')
@check_login
def pay_bill(request):
    data = {
        'status': 1,
        'msg': 'request alipay'
    }

    orderid = request.POST.get('orderid')
    order = Order.objects.filter(user_id=request.user.id, id=orderid).first()

    # 请求支付链接
    data['re_url'] = make_alipay_bill(order)

    return JsonResponse(data)
