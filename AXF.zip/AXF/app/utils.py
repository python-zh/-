from django.http import JsonResponse

from app import error_code
from app.models import User

#判断是否登录的装饰器
def check_login(fun):
    def inner(request, *args, **kwargs):

        #print('this is check login', request.path)

        #判断是否登录
        userid = request.session.get('userid')

        if not userid:

            return JsonResponse({'status':error_code.NOT_LOGIN,'msg':'not login'})

        #如果已经登录了
        users = User.objects.filter(id=userid)

        if not users.exists():
            return JsonResponse({'status': error_code.NOT_LOGIN, 'msg': 'not login'})


        user = users.first()

        #把用户动态的加到request上面
        request.user = user

        #实现原来函数的功能
        return fun(request, *args, **kwargs)
    return inner



#判断请求类型装饰器
def check_method(method_type):
    def wrapper(fun):
        def inner(request, *args, **kwargs):

            #如果请求方式不对
            if request.method != method_type:
                data = {
                    'status': error_code.REQUEST_ERROR,
                    'msg': 'request method error',
                }

                return JsonResponse(data)

            return fun(request, *args, **kwargs)
        return inner
    return wrapper
