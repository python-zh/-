from django.urls import path
from app.views import *

app_name='axf'

urlpatterns=[
	path('home/',home,name='home'),   #首页
	path('market/<typeid>/<childtype_id>/<sorttype_id>/',market,name='market'),#闪购
	path('cart/',cart,name='cart'),#购物车
	path('mine/',mine,name='mine'),#我的
	
	path('register/', register, name='register'), #注册
	path('login/', login, name='login'),#登录
    path('register_handler/', register_handler, name='register_handler'), #注册操作
	path('virify_user/', virify_user, name='virify_user'),  # 检测用户名
    path('login_handler/', login_handler, name='login_handler'), #登录操作
	path('logout/', logout, name='logout'), #注销
	
	path('add_to_cart/',add_to_cart,name='add_to_cart'),#添加到购物车
	path('cart_num_add/',cart_num_add,name='cart_num_add'),#购物车商品数量增加
	path('cart_num_reduce/',cart_num_reduce,name='cart_num_reduce'),#购物车商品数量减少
	path('cart_delete/',cart_delete,name='cart_delete'),#删除购物车商品
	path('cart_select/',cart_select,name='cart_select'),#勾选购物车商品
	path('all_select_or_none/',all_select_or_none,name='all_select_or_none'),#全选购物车商品或者变成全不选
	
	path('pay_result/',pay_result,name='pay_result'),#支付宝回调接口
	path('add_order/',add_order,name='add_order'),#添加订单
	path('order_unpay/',order_unpay,name='order_unpay'),#未支付订单
	path('pay_bill/',pay_bill,name='pay_bill'),#支付订单
]