


NOT_LOGIN = -1      #登录错误
REQUEST_ERROR = -2  #请求错误
NO_THIS_CART = -3   #没有这条记录