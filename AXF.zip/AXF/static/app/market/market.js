$(function () {

    $('#all_type').click(function () {
        console.log(1);
        $('#all_type_container').toggle(); //显示和隐藏切换
        $('#all_type_icon').toggleClass('glyphicon-chevron-down glyphicon-chevron-up')

        //主动触发 空白的区域综合排序 点击
        $('#sort_type_container').trigger('click')
    });
    //点击空白的区域，回收类型排序div
    $('#all_type_container').click(function () {
        $(this).hide();
        //$('#all_type_icon').removeClass('glyphicon-chevron-down glyphicon-chevron-up').addClass('glyphicon-chevron-down')
        $('#all_type_icon').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')

    });


    $('#sort_type').click(function () {
        console.log(1);
        $('#sort_type_container').toggle(); //显示和隐藏切换
        $('#sort_type_icon').toggleClass('glyphicon-chevron-down glyphicon-chevron-up')

        //主动触发 空白的区域全部类型的 点击
        $('#all_type_container').trigger('click')
    });

    //点击空白的区域，回收综合排序div
    $('#sort_type_container').click(function () {
        $(this).hide();
        //$('#all_type_icon').removeClass('glyphicon-chevron-down glyphicon-chevron-up').addClass('glyphicon-chevron-down')
        $('#sort_type_icon').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')
    });

    $('.addtocart').click(function () {
        // console.log(1);
        //取到商品的id
        let goodsid=$(this).attr('goodsid');
        console.log(goodsid);
        //取到商品的数量
        let num=$(this).prev().children('span').html();
        console.log(num);

        $.get('/axf/add_to_cart/', {goodsid:goodsid, num:num}, function (data) {
            console.log(data);
            //判断是否返回成功
            if(data.status === 1){
                alert('添加到购物成功')
            } else if (data.status = -1){
                //没有登录，跳转到登录页
                window.location.href = '/axf/login/'
            }
        })

    });

    $('.add').click(function () {
        let num=$(this).prev();
        num.html(parseInt(num.html())+1);
    });

     $('.sub').click(function () {
        let num=$(this).next();

        //判断数量必须大于１
        if (parseInt(num.html())>1)
        num.html(parseInt(num.html())-1);
    });



});