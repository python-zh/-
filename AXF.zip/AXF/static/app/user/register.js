$(function () {

    // let u_flag = false;
    // let p_flag = false;
    // let r_flag = false;
    // let e_flag = false;
    //
    //
    //
    //
    // //当用户名改变时
    // $('#username').change(function () {
    //     console.log(1);
    //     let value = $(this).val();
    //     console.log(value)
    //
    //     if (/^[a-zA-Z_].{5,17}$/.test(value)){
    //         console.log('good')
    //         $('#u_msg').html('用户名正确').css('color','green')
    //         u_flag = true
    //
    //     }else {
    //         $('#u_msg').html('用户名格式有误').css('color','red')
    //         u_flag = false
    //     }
    // });
    //
    // $('#password').change(function () {
    //     let value = $(this).val();
    //     console.log(value)
    //     if (/^.{8,}$/.test(value)){
    //         $('#p_msg').html('密码格式正确').css('color','green')
    //         p_flag = true
    //     } else {
    //         $('#p_msg').html('密码格式不正确').css('color','red')
    //         p_flag = false
    //     }
    // });
    //
    // //确认密码
    // $('#re_password').change(function () {
    //     let value = $(this).val();
    //     let password = $('#password').val();
    //     if (value === password){
    //         $('#r_msg').html('密码一致').css('color','green')
    //         r_flag = true
    //     }else {
    //         $('#r_msg').html('密码不一致').css('color','red')
    //         r_flag = false
    //     }
    // });
    //
    // //邮箱 \w+@\w(\.\w+)+
    // $('#email').change(function () {
    //     if ( /^\w+@\w+(\.\w+)+$/.test($(this).val()) ){
    //         $('#e_msg').html('邮箱格式正确').css('color','green')
    //         e_flag = true
    //     } else {
    //         $('#e_msg').html('邮箱格式不正确').css('color','red')
    //         e_flag = false
    //     }
    // })



    let u_flag = false;
    let p_flag = false;
    let r_flag = false;
    let e_flag = false;

    // function vv() {
    //
    // }

    let virify_user=function(){
        let value = $('#username').val();

        if (value){

            console.log(1);

            console.log(value);

            if (/^[a-zA-Z_].{5,17}$/.test(value)){
                console.log('good');

                $.get('/axf/virify_user/', {username:value}, function (data) {
                    if (data.status === 1){
                        $('#u_msg').html('用户已经存在').css('color','orange');
                        u_flag = false
                    } else {
                        $('#u_msg').html('用户名正确').css('color','green');

                        u_flag=true
                    }
                })

            }else {
                $('#u_msg').html('用户名格式有误').css('color','red');
                u_flag = false
            }
        }

    };

    //当用户名改变时
    $('#username').change(function () {
        virify_user()
    });

    let virify_password=function(){

        let value = $('#password').val();
        if (value){
            console.log(value)
            if (/^.{8,}$/.test(value)){
                $('#p_msg').html('密码格式正确').css('color','green')
                p_flag = true
            } else {
                $('#p_msg').html('密码格式不正确').css('color','red')
                p_flag = false
            }
        }

    };

    $('#password').change(function () {
        virify_password()
    });


    let virify_repassword=function(){

        let value = $('#re_password').val();
        let password = $('#password').val();

        if (value){
            if (value === password){
                $('#r_msg').html('密码一致').css('color','green');
                r_flag = true
            }else {
                $('#r_msg').html('密码不一致').css('color','red');
                r_flag = false
            }
        }

    };
    //确认密码
    $('#re_password').change(function (){
        virify_repassword()
    });


    let virify_email=function(){
        let email = $('#email').val();

        //如果email不为空
        if (email){
            if ( /^\w+@\w+(\.\w+)+$/.test(email) ){
                $('#e_msg').html('邮箱格式正确').css('color','green');
                e_flag = true
            } else {
                $('#e_msg').html('邮箱格式不正确').css('color','red');
                e_flag = false
            }
        }

    };
    //邮箱 \w+@\w(\.\w+)+
    $('#email').change(function () {
        virify_email()
    });


    $('#register_button').click(function () {

        //所有的验证都通过
        // if (u_flag && p_flag && r_flag && e_flag){
        //     return true
        // }else {
        //     return false
        // }

        return (u_flag && p_flag && r_flag && e_flag)
    });

    //页面加载时去判断是否符合格式规则
    virify_user();
    virify_email();
    virify_password();
    virify_repassword();
});