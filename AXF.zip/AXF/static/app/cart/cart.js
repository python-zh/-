$(function () {
    //增加数量
    $('.add').click(function () {
        console.log('add');
        //取到cart.id
        let cartid = $(this).parents('li').attr('cartid');
        let that = this;
        console.log(cartid);
        $.post('/axf/cart_num_add/', {cartid: cartid}, function (data) {
            console.log(data);
            // 成功
            if (data.status === 1) {
                $(that).prev().html(data.num);
                calculate_price();
            } else if (data.status === -1) {
                window.location.href = '/axf/login/'
            } else {
                console.log(data.msg);
            }
        })
    });
    //数量减少
    $('.sub').click(function () {
        console.log('sub');
        //取到cart.id
        let cartid = $(this).parents('li').attr('cartid');
        let that = this;
        console.log(cartid);
        $.post('/axf/cart_num_reduce/', {cartid: cartid}, function (data) {
            //console.log(data)
            //成功
            if (data.status === 1) {
                $(that).next().html(data.num);
                calculate_price();
            } else if (data.status === -1) {
                window.location.href = '/axf/login/'
            } else {
                console.log(data.msg)
            }

        })
    });

    //删除
    $('.delbtn').click(function () {
        console.log('delete');
        //取到cart.id
        let cartid = $(this).parents('li').attr('cartid');
        let that = this;
        console.log(cartid);
        $.post('/axf/cart_delete/', {cartid: cartid}, function (data) {
            //console.log(data)
            //成功
            if (data.status === 1) {
                $(that).parents('li').remove();
                calculate_price();
            } else if (data.status === -1) {
                window.location.href = '/axf/login/'
            } else {
                console.log(data.msg)
            }

        })
    });


    //勾选
    $('.cartlistcheck').click(function () {
        let cartid = $(this).parents('li').attr('cartid');
        let that = this;

        let is_selected = $(this).children('span').children('span').html() ? 0 : 1;
        console.log(is_selected);
        $.post('/axf/cart_select/', {cartid: cartid, select: is_selected}, function (data) {
            //console.log(data)
            //成功
            if (data.status === 1) {
                $(that).children('span').children('span').html(is_selected ? '√' : '')
                 //每次点击运行全选打钩函数
                 check_all_select();
                　calculate_price();
            } else if (data.status === -1) {
                window.location.href = '/axf/login/'
            } else {
                console.log(data.msg)
            }

        })


    });


    //全选
    $('#all_select').click(function () {
        //console.log(1)
        let select_status = $(this).find('span').find('span').html();
        //传到后台的状态，0:把购物车中所有的沟去掉，1：购物车中所有商品打钩
        let all_select = select_status ? 0 : 1;
        let that = this;
        $.post('/axf/all_select_or_none/', {all_select: all_select}, function (data) {
            console.log(data);
            if (data.status === 1) {
                $(that).find('span').find('span').html(select_status ? '' : '√');
                $('.menuList').find('span').find('span').html(select_status?'':'√');

                calculate_price()
            }
        });
        //console.log(select_status)
    });


    //核对　'√'　的数量
    function check_all_select() {

        let select_list = [];
        $('.menuList').each(function () {
            //console.log(1)
            let select = $(this).find('span').find('span').html();
            console.log(select);
            //如果打钩了，就加入select_list
            if (select) {
                select_list.push(select)
            }
        });
        console.log(select_list.length);

        if (select_list.length < $('.menuList').length) {
            $('#all_select').find('span').find('span').html('');
        } else if (select_list.length === $('.menuList').length) {
            $('#all_select').find('span').find('span').html('√')
        }
    }

     //计算价格
     function calculate_price(){

        let total_price = 0;

        $('.menuList').each(function () {
            let select = $(this).find('span').find('span').html();
            //取到打钩的商品
            if (select){
                //数量
                let num = $(this).find('.num').html();
                //价格
                let price = $(this).find('.presentPrice').html();
                // 总价 = 每个商品总价 + 数量 × 价格
                total_price += parseInt(num) * parseFloat(price);
            }
        });

        $('#total_price').html(total_price.toFixed(2))
    //     保留两位小数
    }

    //写在外面就可以去调用里面的方法,页面加载的时候运行这些函数
    check_all_select();
    calculate_price();

    //跳转到支付链接
    $('#calculate_price').click(function () {

        $.get('/axf/add_order/',function (data) {
            //console.log(data)
            if (data.status === 1){
                window.location.href = data.re_url
            }else {
                console.log(data)
            }
        })
    })



});