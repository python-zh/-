$(function () {

    $('.pay_button').click(function () {
        //取到订单id
        let orderid = $(this).attr('orderid');

        console.log(orderid);
        $.post('/axf/pay_bill/', {orderid:orderid},function (data) {
            console.log(data);
            if (data.status === 1){
                window.location.href = data.re_url
            }

        })
    })

})