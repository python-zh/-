$(function () {
    //轮播图
    new Swiper ('.swiper-container',{
        //循环模式选项
        loop:true,
        //如果需要分页器
        pagination:'.swiper-pagination',
        //自动播放时间
        autoplay:3000,
    });

    //必买　轮播
    new Swiper ('#swiperMenu',{
        // 展示３张
        slidesPerView:3,
        //循环模式选项
        loop:true,
         //自动播放时间
        autoplay:3000,

    })

})